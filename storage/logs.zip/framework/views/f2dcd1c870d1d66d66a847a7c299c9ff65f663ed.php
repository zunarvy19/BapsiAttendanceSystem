
<link rel="stylesheet" href="<?php echo e(asset('bootstrap5/css/bootstrap.min.css')); ?>">
<!----===== Boxicons CSS ===== -->


<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

<?php echo \Livewire\Livewire::styles(); ?><?php /**PATH C:\xampp\htdocs\Laravel\absensi-app - Copy\resources\views/partials/styles.blade.php ENDPATH**/ ?>