

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <div class="card mb-3" style="max-width: min-content">
            <div class="card-body">
                <img src="<?php echo e($qrcode); ?>" alt="" id="qrcode">
            </div>
        </div>
        <div class="mb-3">
            <a href="<?php echo e(route('presences.qrcode.download-pdf', ['code' => $code])); ?>" class="btn btn-primary">Download
                PDF</a>
        </div>
        <div><small class="text-muted">Untuk mendownload QrCode SVG (agar bisa diedit) silahkan klik kiri pada
                gambar qrcode, lalu download.</small></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\absensi-app\resources\views/presences/qrcode.blade.php ENDPATH**/ ?>