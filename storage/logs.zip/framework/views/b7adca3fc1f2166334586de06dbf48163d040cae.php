
<script src="<?php echo e(asset('bootstrap5/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"
    integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous">
</script>

<script>
    feather.replace({ 'aria-hidden': 'true' })
</script>


<script type="module" src="<?php echo e(asset('js/main.js')); ?>"></script>

<?php echo \Livewire\Livewire::scripts(); ?><?php /**PATH C:\xampp\htdocs\Laravel\absensi-app\resources\views/partials/scripts.blade.php ENDPATH**/ ?>