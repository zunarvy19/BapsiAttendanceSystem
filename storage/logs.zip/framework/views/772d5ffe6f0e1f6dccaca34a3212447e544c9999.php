

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-md-7 mx-auto">
            <div class="mb-2">
                <?php echo $__env->make('partials.attendance-badges', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('permission-form', ['attendanceId' => ''.e($attendance->id).''])->html();
} elseif ($_instance->childHasBeenRendered('XsDbH5A')) {
    $componentId = $_instance->getRenderedChildComponentId('XsDbH5A');
    $componentTag = $_instance->getRenderedChildComponentTagName('XsDbH5A');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XsDbH5A');
} else {
    $response = \Livewire\Livewire::mount('permission-form', ['attendanceId' => ''.e($attendance->id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('XsDbH5A', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\absensi-app\resources\views/home/permission.blade.php ENDPATH**/ ?>