<div>
    <div class="toast-container toast-container position-fixed top-0 end-0 p-3 toast-overflow" id="toast-container">

    </div>
</div><?php /**PATH C:\xampp\htdocs\Laravel\absensi-app - Copy\resources\views/components/toast-container.blade.php ENDPATH**/ ?>